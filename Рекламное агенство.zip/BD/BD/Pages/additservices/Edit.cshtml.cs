﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BD.Data;
using WebBD_AdAgency.Models;

namespace BD.Pages.additservices
{
    public class EditModel : PageModel
    {
        private readonly BD.Data.BDContext _context;

        public EditModel(BD.Data.BDContext context)
        {
            _context = context;
        }

        [BindProperty]
        public AdditService AdditService { get; set; }

        public async Task<IActionResult> OnGetAsync(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            AdditService = await _context.AdditService.FirstOrDefaultAsync(m => m.ID == id);

            if (AdditService == null)
            {
                return NotFound();
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(AdditService).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdditServiceExists(AdditService.ID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool AdditServiceExists(long id)
        {
            return _context.AdditService.Any(e => e.ID == id);
        }
    }
}
