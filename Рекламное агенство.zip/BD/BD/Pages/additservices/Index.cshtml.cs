﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BD.Data;
using WebBD_AdAgency.Models;

namespace BD.Pages.additservices
{
    public class IndexModel : PageModel
    {
        private readonly BD.Data.BDContext _context;

        public IndexModel(BD.Data.BDContext context)
        {
            _context = context;
        }

        public IList<AdditService> AdditService { get;set; }

        public async Task OnGetAsync()
        {
            AdditService = await _context.AdditService.ToListAsync();
        }
    }
}
