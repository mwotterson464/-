﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BD.Data;
using WebBD_AdAgency.Models;

namespace BD.Pages.locations
{
    public class IndexModel : PageModel
    {
        private readonly BD.Data.BDContext _context;

        public IndexModel(BD.Data.BDContext context)
        {
            _context = context;
        }

        public IList<Location> Location { get;set; }

        public async Task OnGetAsync()
        {
            Location = await _context.Location
                .Include(l => l.TypeAd).ToListAsync();
        }
    }
}
