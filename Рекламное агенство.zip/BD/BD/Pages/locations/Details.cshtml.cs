﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BD.Data;
using WebBD_AdAgency.Models;

namespace BD.Pages.locations
{
    public class DetailsModel : PageModel
    {
        private readonly BD.Data.BDContext _context;

        public DetailsModel(BD.Data.BDContext context)
        {
            _context = context;
        }

        public Location Location { get; set; }

        public async Task<IActionResult> OnGetAsync(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Location = await _context.Location
                .Include(l => l.TypeAd).FirstOrDefaultAsync(m => m.ID == id);

            if (Location == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
