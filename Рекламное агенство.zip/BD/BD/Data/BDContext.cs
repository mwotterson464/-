﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BD_of_the_Insurance_Company.Models;
using WebBD_AdAgency.Models;

namespace BD.Data
{
    public class BDContext : DbContext
    {
        public BDContext (DbContextOptions<BDContext> options)
            : base(options)
        {
        }

        public DbSet<BD_of_the_Insurance_Company.Models.Position> Position { get; set; }

        public DbSet<BD_of_the_Insurance_Company.Models.Staff> Staff { get; set; }

        public DbSet<WebBD_AdAgency.Models.AdditService> AdditService { get; set; }

        public DbSet<WebBD_AdAgency.Models.Location> Location { get; set; }
    }
}
